Lesson Plan: Introduction to AI
Objectives: Define AI; distinguish ML vs. traditional programming; reflect on human-centered AI.
Activities: Mini-lecture; small-group discussion; prompt iteration exercise.
Assessment: Exit ticket with 3 key takeaways.
Materials: Slides Module 1–2; prompt examples.
