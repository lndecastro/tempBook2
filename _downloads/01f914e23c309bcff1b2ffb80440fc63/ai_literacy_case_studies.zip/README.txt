AI Literacy Case Studies — Datasets & Materials
Folders:
- education/: syllabus.txt, rubric.txt, lesson_plan.md
- healthcare/: patient_records.csv (synthetic), guideline.txt (educational)
- environment/: water_quality.csv
- business/: customer_feedback.csv
- arts/: story_seeds.csv
